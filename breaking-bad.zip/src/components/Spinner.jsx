import React from 'react'
import App from '../App';

export default function Spinner() {
    return (
        <div className="spinner-container">
            <div className="loading-spinner">
            </div>
        </div>
    );
}
